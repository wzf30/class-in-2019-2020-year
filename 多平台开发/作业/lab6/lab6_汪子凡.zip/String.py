# -*- coding: utf8 -*- 

StringTable = [[u"当前光标是:IDC_ARROW", u"当前光标是:IDC_CROSS", u"当前光标是:我的光标", u"文件名"],
             [ "The current cursor is:IDC_ARROW", "The current cursor is:IDC_CROSS", "The current cursor is:My Cursor", "filename"]]
