//*************************************************************************************** 
 
// Prototype for the Window Function 

LRESULT CALLBACK MainWndProc(HWND,UINT,WPARAM,LPARAM);

// Prototypes of functions called by WinMain 

BOOL InitApplication(HINSTANCE);
BOOL InitInstance(HINSTANCE,int);

//***************************************************************************************
