#include <windows.h>
#include "hello.h"    // self-defined header
#include <conio.h>  // for getch
#include <tlhelp32.h> // ���պ�����ͷ�ļ�

//***************************************************************************************

int WINAPI WinMain(HINSTANCE hInstance,     // ��ں���
                   HINSTANCE,
                   LPSTR     lpCmdLine,
                   int       nCmdShow  )
{
    if (!InitApplication(hInstance))       // Ӧ�ó�ʼ��
        return FALSE;

    if (!InitInstance(hInstance,nCmdShow)) // ʵ����ʼ��
        return FALSE;

    MSG msg;
    while (GetMessage(&msg, NULL, 0, 0))   // ��Ϣѭ��
    {
        TranslateMessage(&msg);
        DispatchMessage(&msg);
    }

    return (int)msg.wParam;
}

//***************************************************************************************

BOOL InitApplication(HINSTANCE hInstance)   // Ӧ�ó�ʼ��
{
    WNDCLASS  wc;  // Data structure of the window class

    wc.style            = CS_HREDRAW|CS_VREDRAW;
    wc.lpfnWndProc      = (WNDPROC)MainWndProc;  // Name of the Window Function
    wc.cbClsExtra       = 0;
    wc.cbWndExtra       = 0;
    wc.hInstance        = hInstance;
    wc.hIcon            = LoadIcon (NULL, IDI_APPLICATION);
    wc.hCursor          = LoadCursor(NULL, IDC_ARROW);
    wc.hbrBackground    = (HBRUSH)GetStockObject(WHITE_BRUSH);
    wc.lpszMenuName     = NULL;
    wc.lpszClassName    = TEXT("My1stWClass");  // Name of the window class

    return RegisterClass(&wc);
}

//***************************************************************************************

BOOL InitInstance(HINSTANCE hInstance, int nCmdShow)  // ʵ����ʼ��
{
    HWND hWnd = CreateWindow(TEXT("My1stWClass"),     // Name of the window class
                             TEXT("10175102206 ������"), // Title of the window
                             WS_OVERLAPPEDWINDOW,
                             CW_USEDEFAULT,
                             CW_USEDEFAULT,
                             CW_USEDEFAULT,
                             CW_USEDEFAULT,
                             NULL,
                             NULL,
                             hInstance,
                             NULL                                        );
    if (!hWnd) return FALSE;

    ShowWindow(hWnd, nCmdShow);
    UpdateWindow(hWnd);

    return TRUE;
}

//***************************************************************************************

// ���ڹ��̺���

LRESULT CALLBACK MainWndProc(HWND hWnd, UINT message, WPARAM wParam, LPARAM lParam)
{
    LPCTSTR hello = TEXT("Hello, CLASS 17��");   // ��ʾ������

    PAINTSTRUCT ps;
    HDC hdc;

    switch (message) {

        case WM_PAINT:  // ���ڿͻ�����ˢ��

{


            hdc = BeginPaint (hWnd, &ps);
            PROCESSENTRY32 pe32;

            // �����н����Ŀ���
            HANDLE hProcessSnap = CreateToolhelp32Snapshot(TH32CS_SNAPPROCESS, 0);

            // ��ʹ������ṹ֮ǰ�����������Ĵ�С
            pe32.dwSize = sizeof(pe32);

            // �������̿��գ������ʾ������Ϣ
            BOOL bMore = Process32First(hProcessSnap, &pe32);
            int i=50,j=50,cnt=0;
            while (bMore)
            {
                TCHAR s[100];
                wsprintf(s," ID:  %05x   Name:  %s\n", (unsigned)pe32.th32ProcessID,pe32.szExeFile);
                TextOut(hdc,j,i,s,lstrlen(s));
                //printf(" ID:  %05x   Name:  %s\n", (unsigned)pe32.th32ProcessID,pe32.szExeFile);
                // %S for UNICODE string
                bMore = Process32Next(hProcessSnap, &pe32);
                i+=30;
                cnt++;
                if(cnt==21)
                {
                    j+=500;
                    i=50;
                    cnt=0;
                }

            }
            CloseHandle(hProcessSnap); // �ر�snapshot����
            //getch(); //Press any key to end program

            //TextOut(hdc,600,300,hello,lstrlen(hello));
            EndPaint (hWnd, &ps);

            return 0;
}
        case WM_DESTROY: // ���ڹر�

            PostQuitMessage(0);

            return 0;

       default:  // ȱʡ��Ϣ�Ĵ���

           return DefWindowProc(hWnd, message, wParam, lParam);
   }

}
