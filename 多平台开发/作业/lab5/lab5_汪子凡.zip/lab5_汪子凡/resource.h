//{{NO_DEPENDENCIES}}
// Microsoft Visual C++ ���ɵİ����ļ���
// �� Resource.rc ʹ��
//
#define IDI_ICON1                       101
#define IDB_BITMAP1                     102
#define IDB_BITMAP2                     103
#define IDB_BITMAP3                     104
#define IDC_CURSOR1                     105
#define IDD_DIALOG1                     106
#define IDD_DIALOG2                     108
#define IDR_MENU_CH                     111
#define IDR_MENU_EG                     112
#define IDS_CHINESE1                    113
#define IDS_CHINESE2                    114
#define IDR_ACCELERATOR1                1114
#define IDS_CHINESE3                    115
#define IDS_ENGLISH1                    116
#define IDS_ENGLISH2                    117
#define IDS_ENGLISH3                    118
#define IDOK1                           1001
#define IDCANCEL1                       1002
#define IDC_CHECK1                      1003
#define IDC_CHECK2                      1004
#define IDC_CHECK3                      1005
#define IDC_RADIO1                      1007
#define IDC_RADIO2                      1008
#define IDC_RADIO3                      1009
#define IDOK2                           1010
#define IDCANCEL2                       1011
#define ID_FILE_EXIT                    40004
#define ID_DIALOG_A                     40007
#define ID_DIALOG_B                     40008
#define ID_DIALOG_C                     40009
#define ID_CUSSOR1                      40010
#define ID_CUSSOR2                      40011
#define ID_CUSSOR3                      40012
#define ID_LANGUAGE_CH                  40014
#define ID_LANGUAGE_EG                  40015
#define ID_MESSAGESHOW                  40016

// Next default values for new objects
//
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        115
#define _APS_NEXT_COMMAND_VALUE         40029
#define _APS_NEXT_CONTROL_VALUE         1012
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
