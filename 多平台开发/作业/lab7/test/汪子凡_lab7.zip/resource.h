//{{NO_DEPENDENCIES}}
// Microsoft Visual C++ ���ɵİ����ļ���
// �� Resource.rc ʹ��
//
#define IDI_ICON1                       101
#define IDR_MENU1                       102
#define IDR_ACCELERATOR1                103
#define IDD_DIALOG1                     104
#define IDD_DIALOG2                     106
#define OK_B                            1001
#define CANCEL_B                        1002
#define IDC_EDIT1                       1007
#define IDC_EDIT2                       1008
#define IDC_T_EDIT1                     1008
#define IDC_EDIT3                       1009
#define IDC_T_EDIT2                     1009
#define IDC_EDIT4                       1010
#define IDC_T_EDIT3                     1010
#define IDC_EDIT5                       1011
#define IDC_T_EDIT4                     1011
#define IDC_EDIT6                       1012
#define IDC_T_EDIT5                     1012
#define IDC_EDIT7                       1013
#define IDC_T_EDIT6                     1013
#define IDC_EDIT8                       1014
#define IDC_STATIC0                     70
#define IDC_STATIC1                     71
#define IDC_STATIC2                     72
#define IDC_STATIC3                     73
#define IDC_STATIC4                     74
#define IDC_STATIC5                     75
#define IDC_STATIC6                     76
#define IDC_STATIC7                     77
#define IDC_STATIC8                     78
#define IDC_STATIC9                     79
#define ID_FILE_NEW                     40001
#define ID_FILE_OPEN                    40002
#define ID_FILE_SAVE                    40003
#define ID_FILE_SAVEAS                  40004
#define ID_FILE_RECENT                  40005
#define ID_SETTINGS_CHANGE              40006
#define ID_CHANGE_BEIZER                40007
#define ID_CHANGE_TRIANGLE              40008
#define ID_SETTINGS_REPAINT             40009
#define ID_SETTINGS_MODIFY              40010
#define ID_HELP_LAB7HELP                40011
#define ID_HELP_ABOUT                   40012

#define ID_RECENTFILES_1                   50001
#define ID_RECENTFILES_2                   50002
#define ID_RECENTFILES_3                   50003

// Next default values for new objects
//
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        108
#define _APS_NEXT_COMMAND_VALUE         40018
#define _APS_NEXT_CONTROL_VALUE         1009
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
